import ProjectsSection from "../ProjectsSection";

export default function ProjectsSectionExample() {
  return <ProjectsSection />;
}
